from django.shortcuts import render
from django.contrib.auth.models import User
from assurance.models import *
# Create your views here.


class LoginView(SuccessURLAllowedHostsMixin, FormView)
form_class = AuthenticationForm
authentication_form = None
redirect_field_name = REDIRECT_FIELD_NAME
template_name ='accounts/login.html'
redirect_authenticated_user =False
extra_context = None
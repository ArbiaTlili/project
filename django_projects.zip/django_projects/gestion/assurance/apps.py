from django.apps import AppConfig


class AssuranceConfig(AppConfig):
    name = 'assurance'
